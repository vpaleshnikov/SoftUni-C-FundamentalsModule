﻿public interface IStrategy
{
    int Calculate(int first, int second);
}
