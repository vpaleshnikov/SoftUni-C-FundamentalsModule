﻿using System;

public class PersonClass
{
    static void Main(string[] args)
    {
    }
}

