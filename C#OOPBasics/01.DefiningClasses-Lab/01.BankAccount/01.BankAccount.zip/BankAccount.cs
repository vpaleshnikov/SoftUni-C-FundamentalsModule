﻿public class BankAccount
{
    private int Id;

    public int ID
    {
        get { return Id; }
        set { Id = value; }
    }

    private decimal balance;

    public decimal Balance
    {
        get { return balance; }
        set { balance = value; }
    }
}