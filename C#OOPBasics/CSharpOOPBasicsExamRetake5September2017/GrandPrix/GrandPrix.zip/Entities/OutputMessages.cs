﻿public class OutputMessages
{
    public static string BlownTyre => "Blown Tyre";

    public static string OutOfFuel => "Out of fuel";

    public static string Crashed => "Crashed";

    public static string InvalidLaps => "There is no time! On lap {0}.";
}